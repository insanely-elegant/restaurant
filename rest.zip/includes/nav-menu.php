<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" style="color: turquoise">Silver Glen</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="booking.php">Book a Table</a></li>
      <li><a href="booking-history.php">See Past Bookings</a></li>
    </ul>
  </div>
</nav>